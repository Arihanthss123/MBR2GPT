﻿This program has no warranty 


TRY AT YOUR OWN RISK


This program converts MBR TO GPT


It will work in Windows 10


It can’t be confirmed to work in older versions of windows


If this program is sold ask a refund This is a free program 


It is hosted on github


Link =


Process :


1.Extract the .zip file


2.run the installer


3.read the readme file and close it


4.Select Option 1 for Converting From MBR TO GPT or Select option 2 for closing the application


5.Go to your firmware and change Legacy/CSM/MBR to UEFI/GPT